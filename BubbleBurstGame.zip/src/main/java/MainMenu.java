// MainMenu.java
import javax.swing.*;
import java.awt.*;

public class MainMenu extends JFrame {
    private JButton startButton;
    private JButton restartButton;
    private JSlider difficultySlider;
    private GamePanel gamePanel;
    private JFrame gameFrame;

    public MainMenu() {
        setTitle("Bubble Burst - Main Menu");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        // Difficulty Slider
        JPanel sliderPanel = new JPanel();
        JLabel sliderLabel = new JLabel("Difficulty: ");
        difficultySlider = new JSlider(JSlider.HORIZONTAL, 0, 2, 0);
        difficultySlider.setMajorTickSpacing(1);
        difficultySlider.setPaintTicks(true);
        difficultySlider.setPaintLabels(true);

        // Create label table for slider
        java.util.Hashtable<Integer, JLabel> labelTable = new java.util.Hashtable<>();
        labelTable.put(0, new JLabel("Easy"));
        labelTable.put(1, new JLabel("Medium"));
        labelTable.put(2, new JLabel("Hard"));
        difficultySlider.setLabelTable(labelTable);

        sliderPanel.add(sliderLabel);
        sliderPanel.add(difficultySlider);

        // Buttons
        JPanel buttonPanel = new JPanel();
        startButton = new JButton("Start");
        restartButton = new JButton("Restart");
        restartButton.setEnabled(false);

        startButton.addActionListener(e -> startGame());
        restartButton.addActionListener(e -> restartGame());

        buttonPanel.add(startButton);
        buttonPanel.add(restartButton);

        mainPanel.add(Box.createVerticalStrut(50));
        mainPanel.add(sliderPanel);
        mainPanel.add(Box.createVerticalStrut(30));
        mainPanel.add(buttonPanel);

        add(mainPanel);
    }

    private void startGame() {
        int difficulty = getDifficultyBubbleCount();
        if (gameFrame == null) {
            gameFrame = new JFrame("Bubble Burst - Game");
            gameFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            gameFrame.setSize(800, 600);
            gameFrame.setLocationRelativeTo(null);
        }

        gamePanel = new GamePanel(this, difficulty);
        gameFrame.getContentPane().removeAll();
        gameFrame.add(gamePanel);
        gameFrame.setVisible(true);
        startButton.setEnabled(false);
        restartButton.setEnabled(true);
        gamePanel.startRound();
    }

    private void restartGame() {
        if (gamePanel != null) {
            gamePanel.resetGame();
        }
        startGame();
    }

    private int getDifficultyBubbleCount() {
        switch (difficultySlider.getValue()) {
            case 0: return 4; // Easy
            case 1: return 5; // Medium
            case 2: return 6; // Hard
            default: return 4;
        }
    }
}