// GamePanel.java
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class GamePanel extends JPanel {
    private final MainMenu mainMenu;
    private final int numBubbles;
    private List<Bubble> bubbles;
    private int round = 1;
    private Timer gameTimer;
    private int timeLeft;
    private boolean isPlacingBubbles = true;
    private int placedBubbles = 0;
    private boolean gameOver = false;
    private int currentScore = 0;
    private int bubblesPopped = 0;
    private int totalBubblesPopped = 0;

    public GamePanel(MainMenu mainMenu, int numBubbles) {
        this.mainMenu = mainMenu;
        this.numBubbles = numBubbles;
        this.bubbles = new ArrayList<>();

        setBackground(Color.WHITE);
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                handleMouseClick(e.getPoint());
            }
        });
    }

    public void startRound() {
        if (round == 1) {
            isPlacingBubbles = true;
            placedBubbles = 0;
            bubbles.clear();
            currentScore = 0;
            totalBubblesPopped = 0;
        } else {
            repositionBubbles();
        }

        bubblesPopped = 0;
        timeLeft = Math.max(5, 15 - (round - 1));
        startTimer();
    }

    private void startTimer() {
        if (gameTimer != null) {
            gameTimer.stop();
        }

        gameTimer = new Timer(1000, e -> {
            timeLeft--;
            if (timeLeft <= 0) {
                endGame();
            }
            repaint();
        });
        gameTimer.start();
    }

    private void calculateScore(int timeBonus) {
        // Base points for popping a bubble
        int basePoints = 100;
        // Bonus points based on round
        int roundBonus = round * 50;
        // Time bonus
        int timeBonusPoints = timeBonus * 10;

        currentScore += basePoints + roundBonus + timeBonusPoints;
    }

    private void handleMouseClick(Point p) {
        if (gameOver) return;

        if (isPlacingBubbles) {
            if (isValidBubblePosition(p.x, p.y)) {
                bubbles.add(new Bubble(p.x, p.y));
                placedBubbles++;
                if (placedBubbles == numBubbles) {
                    isPlacingBubbles = false;
                }
            }
        } else {
            boolean bubbleBurst = false;
            for (Bubble bubble : bubbles) {
                if (!bubble.isBurst() && bubble.contains(p)) {
                    bubble.burst();
                    bubblesPopped++;
                    totalBubblesPopped++;
                    calculateScore(timeLeft);
                    bubbleBurst = true;
                    break;
                }
            }

            if (allBubblesBurst()) {
                if (round < 10) {
                    round++;
                    startRound();
                } else {
                    showFinalScore();
                    endGame();
                }
            }
        }
        repaint();
    }

    private void showFinalScore() {
        String message = String.format(
            "Game Complete!\n" +
            "Final Score: %d\n" +
            "Total Bubbles Popped: %d\n" +
            "Rounds Completed: %d", 
            currentScore, totalBubblesPopped, round
        );
        JOptionPane.showMessageDialog(this, message, "Game Over", JOptionPane.INFORMATION_MESSAGE);
    }

    private boolean isValidBubblePosition(int x, int y) {
        Bubble tempBubble = new Bubble(x, y);

        // Check panel bounds
        if (x < tempBubble.getRadius() || x > getWidth() - tempBubble.getRadius() ||
            y < tempBubble.getRadius() || y > getHeight() - tempBubble.getRadius()) {
            JOptionPane.showMessageDialog(this, 
                "Invalid position! Bubble must be fully within the playing field.",
                "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        // Check collision with other bubbles
        for (Bubble existing : bubbles) {
            if (tempBubble.intersects(existing)) {
                JOptionPane.showMessageDialog(this, 
                    "Invalid position! Bubbles cannot overlap.",
                    "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }

        return true;
    }

    private void repositionBubbles() {
        bubbles.clear();
        for (int i = 0; i < numBubbles; i++) {
            Bubble newBubble;
            int attempts = 0;
            do {
                int x = (int)(Math.random() * (getWidth() - 60) + 30);
                int y = (int)(Math.random() * (getHeight() - 60) + 30);
                newBubble = new Bubble(x, y);
                attempts++;
            } while (checkCollisions(newBubble) && attempts < 100);

            if (attempts < 100) {
                bubbles.add(newBubble);
            }
        }
    }

    private boolean checkCollisions(Bubble newBubble) {
        for (Bubble existing : bubbles) {
            if (newBubble.intersects(existing)) {
                return true;
            }
        }
        return false;
    }

    private boolean allBubblesBurst() {
        return bubbles.stream().allMatch(Bubble::isBurst);
    }

    private void endGame() {
        gameOver = true;
        if (gameTimer != null) {
            gameTimer.stop();
        }
        showFinalScore();
    }

    public void resetGame() {
        round = 1;
        gameOver = false;
        isPlacingBubbles = true;
        placedBubbles = 0;
        bubbles.clear();
        currentScore = 0;
        totalBubblesPopped = 0;
        bubblesPopped = 0;
        if (gameTimer != null) {
            gameTimer.stop();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Draw bubbles
        for (Bubble bubble : bubbles) {
            bubble.draw(g2d);
        }

        // Draw UI information
        g2d.setColor(Color.BLACK);
        g2d.setFont(new Font("Arial", Font.BOLD, 20));

        // Draw round information
        g2d.drawString("Round: " + round + "/10", 10, 30);

        // Draw timer with different colors based on time remaining
        if (timeLeft <= 5) {
            g2d.setColor(Color.RED);
        } else if (timeLeft <= 10) {
            g2d.setColor(Color.ORANGE);
        }
        g2d.drawString("Time: " + timeLeft + "s", getWidth() - 120, 30);

        // Draw score
        g2d.setColor(Color.BLUE);
        g2d.drawString("Score: " + currentScore, getWidth()/2 - 60, 30);

        // Draw bubble placement instructions if in placement phase
        if (isPlacingBubbles) {
            g2d.setColor(Color.BLACK);
            g2d.drawString("Place bubbles: " + placedBubbles + "/" + numBubbles, 
                          getWidth()/2 - 100, getHeight() - 20);
        } else {
            // Draw bubbles popped in current round
            g2d.setColor(Color.GREEN.darker());
            g2d.drawString("Bubbles popped: " + bubblesPopped + "/" + numBubbles, 
                          getWidth()/2 - 100, getHeight() - 20);
        }
    }
}