// Bubble.java
import java.awt.*;
import java.awt.geom.Ellipse2D;

public class Bubble {
    private double x;
    private double y;
    private final int radius = 30;
    private boolean burst = false;
    private Color color;

    public Bubble(int x, int y) {
        this.x = x;
        this.y = y;
        this.color = new Color(
            (float)Math.random(),
            (float)Math.random(),
            (float)Math.random(),
            0.8f
        );
    }

    public void draw(Graphics2D g2d) {
        if (!burst) {
            g2d.setColor(color);
            g2d.fill(new Ellipse2D.Double(x - radius, y - radius, radius * 2, radius * 2));
            g2d.setColor(Color.BLACK);
            g2d.draw(new Ellipse2D.Double(x - radius, y - radius, radius * 2, radius * 2));
        }
    }

    public boolean contains(Point p) {
        return !burst && Math.hypot(p.x - x, p.y - y) <= radius;
    }

    public void burst() {
        this.burst = true;
    }

    public boolean isBurst() {
        return burst;
    }

    public void reposition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void repositionLocal(int round, int panelWidth, int panelHeight) {
        int neighborhood = 50 + (round - 1) * 18;
        double newX, newY;
        do {
            newX = x + (Math.random() * 2 - 1) * neighborhood;
            newY = y + (Math.random() * 2 - 1) * neighborhood;
        } while (!isValidPosition(newX, newY, panelWidth, panelHeight));

        x = newX;
        y = newY;
    }

    public boolean intersects(Bubble other) {
        if (other == null || other.isBurst()) return false;
        double distance = Math.hypot(x - other.x, y - other.y);
        return distance < (radius * 2);
    }

    private boolean isValidPosition(double x, double y, int panelWidth, int panelHeight) {
        return x >= radius && x <= panelWidth - radius && 
               y >= radius && y <= panelHeight - radius;
    }

    public double getX() { return x; }
    public double getY() { return y; }
    public int getRadius() { return radius; }
}